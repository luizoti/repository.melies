# -*- coding: utf-8 -*-

"""Defines the BlockedMenu class."""

import xbmcgui
from resources.lib import ADDON_NAME
from resources.lib.gui.gui_utils import get_string
from resources.lib.gui.progressbar import ProgressBar


class BlockedMenu:
    """Provide windows for displaying blocked items and tools for managing them."""

    def __init__(self):
        """__init__ BlockedMenu."""
        self.database = DBShows() #TODO? DBBlocked
        self.progress_dialog = ProgressBar() #TODO: ProgressBar in Blocked???


    def show_all(self):
        """
        Display all blocked items, which are selectable and lead to options.

        Also provides additional options at bottom of menu.
        """
        # TODO?: change blocked movie/episode to just blocked path
        # TODO?: make blocked episode match on both episode AND show
        # TODO: add blocked types: plugin, path
        # TODO: add blocked keywords, let you choose type
        # TODO: initialize blocked list with known bad items
        STR_BACK = get_string(32011)
        STR_BLOCKED_ITEMS = get_string(32007)
        STR_NO_BLOCKED_ITEMS = get_string(32119)
        blocked_items = self.database.get_all_blocked_itens()
        if not blocked_items:
            xbmcgui.Dialog().ok(ADDON_NAME, STR_NO_BLOCKED_ITEMS)
            return
        lines = [f"{x.localize_type()} - [B]{x['value']}[/B]" for x in blocked_items]
        lines += [STR_BACK]
        ret = xbmcgui.Dialog().select(f"{ADDON_NAME} - {STR_BLOCKED_ITEMS}", lines)
        if ret >= 0:
            if ret < len(blocked_items):  # managed item
                for index, item in enumerate(blocked_items):
                    if ret == index:
                        self.options(item)
                        break
            elif lines[ret] == STR_BACK:
                return

    def options(self, item):
        """Provide options for a single blocked item in a dialog window."""
        STR_REMOVE = get_string(32017)
        STR_BACK = get_string(32011)
        STR_BLOCKED_ITEM_OPTIONS = get_string(32099)
        lines = [STR_REMOVE, STR_BACK]
        ret = xbmcgui.Dialog().select(
            f"{ADDON_NAME} - {STR_BLOCKED_ITEM_OPTIONS} - {item['value']}", lines
        )
        if ret >= 0:
            if lines[ret] == STR_REMOVE:
                self.database.delete_entrie_from_blocked(item["value"], item["type"])
            elif lines[ret] == STR_BACK:
                return self.show_all()
        return self.show_all()
