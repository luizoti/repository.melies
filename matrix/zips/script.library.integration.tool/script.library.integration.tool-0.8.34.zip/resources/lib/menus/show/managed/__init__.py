"""Managed Show module."""
