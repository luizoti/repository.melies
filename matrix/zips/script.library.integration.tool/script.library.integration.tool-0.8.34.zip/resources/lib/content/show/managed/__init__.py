"""Managed Shows module."""
